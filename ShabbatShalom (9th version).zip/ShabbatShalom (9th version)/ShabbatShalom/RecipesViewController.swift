//
//  RecipesViewController.swift
//  ShabbatShalom
//
//  Created by Jerry Ren on 4/23/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

import UIKit

class RecipesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Grape Juice"
        
        
    }   
    

}
