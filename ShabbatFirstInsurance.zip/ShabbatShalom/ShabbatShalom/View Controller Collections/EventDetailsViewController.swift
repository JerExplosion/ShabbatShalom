//
//  EventDetailsViewController.swift
//  ShabbatShalom
//
//  Created by Jerry Ren on 4/5/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

import UIKit
import Foundation

class EventDetailsViewController: UIViewController {
    
    @IBOutlet weak var eventNameTextfield: UITextField!
    
    @IBOutlet weak var eventDateTextfield: UITextField!
    // can possibly use a UIDatePicker
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func saveEvent(_ sender: Any) {
        
        guard let eventName = eventNameTextfield.text else { return }
        guard let eventDate = eventDateTextfield.text else { return }
    
        eventNameEntered = eventName

    //    dismiss(animated: true, completion: nil)
        
    }
    
    
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        let destinationViewController = segue.destination as! EventsViewController
//        
//    }
    
    
    
    
    
    
    
    
    @IBAction func backButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
}






//        let eventSpecifics = EventSpecificsModel(eventName: eventName, date: eventDate)
//        print(eventSpecifics)
