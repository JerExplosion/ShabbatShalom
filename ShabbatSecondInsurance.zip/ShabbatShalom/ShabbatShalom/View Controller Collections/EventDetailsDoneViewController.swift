//
//  EventDetailsDoneViewController.swift
//  ShabbatShalom
//
//  Created by Jerry Ren on 4/9/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

import Foundation
import UIKit

class EventDetailsDoneViewController: UIViewController {
 
    override func viewDidLoad() {
        super.viewDidLoad()
        print("EDdone vDL called")
    }
    
    
    
}
