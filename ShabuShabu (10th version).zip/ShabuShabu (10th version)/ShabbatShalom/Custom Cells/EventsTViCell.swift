//
//  EventsTViCell.swift
//  ShabbatShalom
//
//  Created by Jerry Ren on 4/11/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

import Foundation
import UIKit

class EventsTViCell: UITableViewCell {
    
    @IBOutlet weak var evTViCelloLabel: UILabel!
    
    @IBOutlet weak var evTViCelloImageView: UIImageView!
    

    @IBAction func evTViCelloEditButton(_ sender: Any) {
        
    }
    
}
