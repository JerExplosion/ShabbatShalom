//
//  ImageFetcher.swift
//  ShabbatShalom
//
//  Created by Jerry Ren on 5/3/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

import UIKit
import Foundation

// reference g-mine API' proj from a month ago
       
