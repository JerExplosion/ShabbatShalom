//
//  GuestListTViCell.swift
//  ShabbatShalom
//
//  Created by Jerry Ren on 4/13/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

import Foundation

import UIKit

class GuestListTViCell: UITableViewCell {
    
    @IBOutlet weak var guestNameTviCelloLabel: UILabel!
    
    @IBOutlet weak var guestProfileTviCelloImageView: UIImageView!
    
}
