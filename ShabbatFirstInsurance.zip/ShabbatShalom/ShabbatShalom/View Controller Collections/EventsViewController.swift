//
//  EventsViewController.swift
//  ShabbatShalom
//
//  Created by Jerry Ren on 4/5/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//


import UIKit

class EventsViewController: UIViewController {

    @IBOutlet weak var eventsTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        eventsTable.dataSource = self
//        eventsTable.delegate = self
   //     updatingTable()
       
    }
    
    func updatingTable() {
        DispatchQueue.main.async {
            self.eventsTable.reloadData()
        }
    }

}



extension EventsViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = eventsTable.dequeueReusableCell(withIdentifier: GlobalConstants.eventsCell, for: indexPath)
        cell.textLabel?.text = eventNameEntered

     //   updatingTable()  probably harming the cpu Lol
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
}

extension EventsViewController: UITableViewDelegate {
    
    
    
    
    // make sure to check if isUserInteractionEnabled is checked or not
    
}
