//
//  PersistenceRelevant.swift
//  ShabbatShalom
//
//  Created by Jerry Ren on 4/10/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

import CoreData
import Foundation
