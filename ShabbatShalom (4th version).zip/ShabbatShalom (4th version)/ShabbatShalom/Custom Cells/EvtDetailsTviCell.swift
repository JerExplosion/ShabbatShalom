//
//  EvtDetailsTviCell.swift
//  ShabbatShalom
//
//  Created by Jerry Ren on 4/12/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

import UIKit
import Foundation

class EvtDetailsTviCell: UITableViewCell {
    
    
    
    
    
    
}
