//
//  PersistenceRelevant.swift
//  ShabbatShalom
//
//  Created by Jerry Ren on 4/15/20.
//  Copyright © 2020 Jerry Ren. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class PersistenceRelevant {
    
}
